require 'test_helper'

class BcmsMy401kLibrary::ArticleProductsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
