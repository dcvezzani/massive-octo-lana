require 'test_helper'

class BcmsMy401kLibrary::ArticleProductsHelperTest < ActionView::TestCase
end
