class BcmsMy401kLibrary::ArticleProduct < ActiveRecord::Base
  acts_as_content_block
  belongs_to_category
  belongs_to_category
end
