class BcmsMy401kLibrary::ArticleProductsController < Cms::ContentBlockController
end
