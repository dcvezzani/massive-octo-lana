class CreateBcmsMy401kLibraryHeadlineBanners < ActiveRecord::Migration
  def change
    Cms::ContentType.create!(:name => "BcmsMy401kLibrary::HeadlineBanner", :group_name => "BcmsMy401kLibrary::HeadlineBanner")
    create_content_table :bcms_my401k_library_headline_banners, :prefix=>false do |t|
      t.belongs_to :section
      t.text :body, :size => (64.kilobytes + 1)
      t.text :banner_image

      t.timestamps
    end
  end
end
