class BcmsMy401kLibrary::HeadlineBannersController < Cms::ContentBlockController
end
