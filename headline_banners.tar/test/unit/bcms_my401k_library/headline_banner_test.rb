require 'test_helper'

class BcmsMy401kLibrary::HeadlineBannerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
