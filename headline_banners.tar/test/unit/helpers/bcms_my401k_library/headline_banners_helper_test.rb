require 'test_helper'

class BcmsMy401kLibrary::HeadlineBannersHelperTest < ActionView::TestCase
end
