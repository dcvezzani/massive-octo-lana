require 'test_helper'

class BcmsMy401kLibrary::HeadlineBannersControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
