class Cms::ArticlesController < Cms::ContentBlockController
end
