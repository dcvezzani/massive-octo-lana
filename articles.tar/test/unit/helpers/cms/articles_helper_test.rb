require 'test_helper'

class Cms::ArticlesHelperTest < ActionView::TestCase
end
