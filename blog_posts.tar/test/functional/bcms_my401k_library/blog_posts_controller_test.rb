require 'test_helper'

class BcmsMy401kLibrary::BlogPostsControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
