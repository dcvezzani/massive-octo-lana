require 'test_helper'

class BcmsMy401kLibrary::BlogPostsHelperTest < ActionView::TestCase
end
