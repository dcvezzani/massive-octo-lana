class BcmsMy401kLibrary::BlogPostsController < Cms::ContentBlockController
end
