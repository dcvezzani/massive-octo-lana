module BcmsMy401kLibrary
  def self.table_name_prefix
    'bcms_my401k_library_'
  end
end
