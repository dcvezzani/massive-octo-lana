class BcmsMy401kLibrary::BlogPost < ActiveRecord::Base
  acts_as_content_block
  belongs_to_category
  belongs_to_category
end
